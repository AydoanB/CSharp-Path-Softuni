﻿namespace Student_System.Models.Enumerators
{
    public enum ResourceType
    {
        
    }
}