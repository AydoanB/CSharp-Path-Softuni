﻿namespace Student_System.Models.Enumerators
{
    public enum ContentType
    {
        Application,
        Pdf,
        Zip
    }
}