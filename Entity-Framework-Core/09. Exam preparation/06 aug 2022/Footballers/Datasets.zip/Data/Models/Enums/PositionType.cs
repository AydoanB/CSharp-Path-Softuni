﻿namespace Footballers.Data.Models.Enums
{
    public enum PositionType
    {
        Goalkeeper, 
        Defender, 
        Midfielder, 
        Forward
    }
}