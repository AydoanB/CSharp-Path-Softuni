﻿namespace MusicHub.Data.Models.Enums
{
    public enum Genre
    {
        Blue,
        Rap,
        PopMusic,
        Rock,
        Jazz
    }
}